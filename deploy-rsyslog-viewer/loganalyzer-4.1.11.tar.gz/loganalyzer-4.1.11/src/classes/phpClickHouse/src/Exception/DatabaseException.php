<?php

declare(strict_types=1);

namespace ClickHouseDB\Exception;

final class DatabaseException extends QueryException implements ClickHouseException
{
}
